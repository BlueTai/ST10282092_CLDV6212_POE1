﻿using Microsoft.AspNetCore.Mvc;
using TitanTech.Models;
using TitanTech.Services;

namespace TitanTech.Controllers;

public class UploadController : Controller
{
    private readonly IAzureBlobService _blobService;

    public UploadController(IAzureBlobService blobService)
    {
        _blobService = blobService;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index([FromForm] FileUploadModel model)
    {
        if (ModelState.IsValid)
        {
            // Example of file upload to a "payment-proofs" container
            var containerName = "payment-proofs";
            var url = await _blobService.UploadFileAsync(model.ProofOfPayment, containerName);
            ViewBag.UploadUrl = url;
            ViewBag.Message = "File uploaded successfully!";
            return View();
        }
        ViewBag.Message = "File upload failed. Please ensure you have selected a file.";
        return View(model);
    }
}