using Microsoft.AspNetCore.Mvc;
using TitanTech.Models;
using TitanTech.Services;
using System.Linq;

namespace TitanTech.Controllers
{
    public class CustomerController : Controller
    {
        private readonly IAzureStorageService _storageService;

        public CustomerController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        public async Task<IActionResult> Index()
        {
            var customers = await _storageService.GetAllCustomersAsync();
            return View(customers.OrderBy(c => c.CustomerId));
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,Name,Surname,Username,Email,ShippingAddress")] Customer customer)
        {
            if (!ModelState.IsValid) return View(customer);
            await _storageService.AddCustomerAsync(customer);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(string? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _storageService.GetCustomerAsync(id);
            return View(customer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("PartitionKey,RowKey,Timestamp,ETag,CustomerId,Name,Surname,Username,Email,ShippingAddress")] Customer customer)
        {
            if (id != customer.RowKey)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _storageService.UpdateCustomerAsync(customer);
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        public async Task<IActionResult> Delete(string? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var customer = await _storageService.GetCustomerAsync(id);
            return View(customer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _storageService.DeleteCustomerAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}