using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TitanTech.Models;
using TitanTech.Services;
using TitanTech.Models.ViewModels;

namespace TitanTech.Controllers
{
    public class HomeController(IAzureStorageService storageService) : Controller
    {
        public async Task<IActionResult> Index()
        {
            var allProducts = await storageService.GetAllProductsAsync();
            var allCustomers = await storageService.GetAllCustomersAsync();
            var allOrders = await storageService.GetAllOrdersAsync();

            var enumerable = allProducts.ToList();
            var viewModel = new HomeViewModel
            {
                FeaturedProducts = enumerable.OrderByDescending(p => p.ProductId).Take(5),
                CustomerCount = allCustomers.Count(),
                ProductCount = enumerable.Count,
                OrderCount = allOrders.Count()
            };

            return View(viewModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}