﻿using Microsoft.AspNetCore.Mvc;
using TitanTech.Models;
using TitanTech.Services;
using System.Linq;

namespace TitanTech.Controllers
{
    public class ProductController : Controller
    {
        private readonly IAzureStorageService _storageService;
        private readonly IAzureBlobService _blobService;

        public ProductController(IAzureStorageService storageService, IAzureBlobService blobService)
        {
            _storageService = storageService;
            _blobService = blobService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _storageService.GetAllProductsAsync();
            return View(products.OrderBy(p => p.ProductId));
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId,ProductName,Description,Price,StockAvailable")] Product product, IFormFile? imageFile)
        {
            if (ModelState.IsValid)
            {
                // Upload image to Blob Storage
                if (imageFile != null && imageFile.Length > 0)
                {
                    product.ImageUrl = await _blobService.UploadFileAsync(imageFile, "product-images");
                }

                await _storageService.AddProductAsync(product);
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        public async Task<IActionResult> Edit(string id)
        {
            var product = await _storageService.GetProductAsync(id);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("PartitionKey,RowKey,Timestamp,ETag,ProductId,ProductName,Description,Price,StockAvailable")] Product product, IFormFile? newImageFile)
        {
            if (id != product.RowKey)
            {
                return NotFound();
            }

            if (!ModelState.IsValid) return View(product);
            // Handle new image upload
            if (newImageFile != null && newImageFile.Length > 0)
            {
                // Optionally delete old image
                // await _blobService.DeleteFileAsync(Path.GetFileName(product.ImageUrl), "product-images");
                product.ImageUrl = await _blobService.UploadFileAsync(newImageFile, "product-images");
            }

            await _storageService.UpdateProductAsync(product);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(string? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _storageService.GetProductAsync(id);

            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var product = await _storageService.GetProductAsync(id);
            if (true)
            {
                // Delete the associated image from Blob Storage
                if (!string.IsNullOrEmpty(product.ImageUrl))
                {
                    var fileName = Path.GetFileName(new Uri(product.ImageUrl).LocalPath);
                    await _blobService.DeleteFileAsync(fileName, "product-images");
                }
                await _storageService.DeleteProductAsync(id);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}