using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TitanTech.Models;
using TitanTech.Models.ViewModels;
using TitanTech.Services;
using System.Linq;

namespace TitanTech.Controllers
{
    public class OrderController : Controller
    {
        private readonly IAzureStorageService _storageService;

        public OrderController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        public async Task<IActionResult> Index()
        {
            var allOrders = await _storageService.GetAllOrdersAsync();
            var allCustomers = await _storageService.GetAllCustomersAsync();
            var allProducts = await _storageService.GetAllProductsAsync();

            var viewModel = new OrderIndexViewModel
            {
                Orders = allOrders.OrderByDescending(o => o.OrderDate),
                Customers = allCustomers,
                Products = allProducts
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Create()
        {
            var customers = await _storageService.GetAllCustomersAsync();
            var products = await _storageService.GetAllProductsAsync();

            var viewModel = new OrderCreateViewModel
            {
                Order = new Order(),
                Customers = new SelectList(customers, "CustomerId", "Username"),
                Products = new SelectList(products, "ProductId", "ProductName")
            };
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderCreateViewModel viewModel)
        {
            // Simple validation to ensure stock is available
            var product = await _storageService.GetProductAsync(viewModel.Order.ProductId.ToString());
            if (product != null && product.StockAvailable >= viewModel.Order.Quantity)
            {
                // Update the total price
                viewModel.Order.TotalPrice = viewModel.Order.Quantity * product.Price;
                // Generate a new ID for the order
                var allOrders = await _storageService.GetAllOrdersAsync();
                viewModel.Order.OrderId = allOrders.Count() > 0 ? allOrders.Max(o => o.OrderId) + 1 : 1;

                await _storageService.AddOrderAsync(viewModel.Order);

                // Update the product's stock
                product.StockAvailable -= viewModel.Order.Quantity;
                await _storageService.UpdateProductAsync(product);

                return RedirectToAction(nameof(Index));
            }
            // If validation fails, reload the view with the correct data
            var customers = await _storageService.GetAllCustomersAsync();
            var products = await _storageService.GetAllProductsAsync();
            viewModel.Customers = new SelectList(customers, "CustomerId", "Username");
            viewModel.Products = new SelectList(products, "ProductId", "ProductName");
            ModelState.AddModelError("", "Not enough stock available for this product.");
            return View(viewModel);
        }

        public async Task<IActionResult> Edit(string id)
        {
            var order = await _storageService.GetOrderAsync(id);
            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("PartitionKey,RowKey,Timestamp,ETag,OrderId,CustomerId,ProductId,Quantity,TotalPrice,OrderDate,Status")] Order order)
        {
            if (id != order.RowKey)
            {
                return NotFound();
            }

            if (!ModelState.IsValid) return View(order);
            await _storageService.UpdateOrderAsync(order);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(string id)
        {
            var order = await _storageService.GetOrderAsync(id);

            // Get related customer and product for display
            var customer = await _storageService.GetCustomerAsync(order.CustomerId.ToString());
            var product = await _storageService.GetProductAsync(order.ProductId.ToString());

            ViewBag.Customer = customer;
            ViewBag.Product = product;

            return View(order);
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var order = await _storageService.GetOrderAsync(id);
            return View(order);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _storageService.DeleteOrderAsync(id);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> GetProductPrice(string productId)
        {
            var product = await _storageService.GetProductAsync(productId);
            return Json(new { price = product.Price, stock = product.StockAvailable });
        }
    }
}