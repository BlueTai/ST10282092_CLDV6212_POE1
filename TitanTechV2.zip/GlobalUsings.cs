﻿// Global using directives

global using Microsoft.AspNetCore.Http;