using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Azure;
using Azure.Data.Tables;

namespace TitanTech.Models;

// The model now inherits from ITableEntity.
public class Order : ITableEntity
{
    // Parameterless constructor required for Azure Table Storage deserialization
    public Order()
    {
        PartitionKey = "order";
        RowKey = string.Empty;
        Status = "Pending";
        OrderDate = DateTime.Now;
    }

    public Order(string rowKey)
    {
        RowKey = rowKey;
        PartitionKey = "order";
        Status = "Pending";
        OrderDate = DateTime.Now;
    }

    // ITableEntity properties are required.
    public string PartitionKey { get; set; } = "order";
    public string RowKey { get; set; } = string.Empty;
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }

    public int OrderId { get; set; }

    [Required]
    public int CustomerId { get; set; }

    [Required]
    public int ProductId { get; set; }

    [Required]
    public int Quantity { get; set; }

    [Required]
    [Column(TypeName = "decimal(18, 2)")]
    public decimal TotalPrice { get; set; }

    [Required]
    public DateTime OrderDate { get; set; } = DateTime.Now;

    [Required]
    [StringLength(50)]
    public string Status { get; set; } = "Pending";
}