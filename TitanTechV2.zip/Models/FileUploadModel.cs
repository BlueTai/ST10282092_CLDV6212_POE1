﻿using System.ComponentModel.DataAnnotations;

namespace TitanTech;

public class FileUploadModel
{
    public FileUploadModel(IFormFile proofOfPayment)
    {
        ProofOfPayment = proofOfPayment;
    }

    [Required]
    [Display(Name = "Proof of Payment")]
    public IFormFile ProofOfPayment { get; set; }

    public string? OrderId { get; set; }

    public string? CustomerName { get; set; }
}