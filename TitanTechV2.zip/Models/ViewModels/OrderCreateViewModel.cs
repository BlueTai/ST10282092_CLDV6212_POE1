using Microsoft.AspNetCore.Mvc.Rendering;
using TitanTech.Models;

namespace TitanTech.Models.ViewModels
{
    public class OrderCreateViewModel
    {
        public OrderCreateViewModel()
        {
            Order = new Order();
            Customers = new SelectList(new List<Customer>(), "CustomerId", "Username");
            Products = new SelectList(new List<Product>(), "ProductId", "ProductName");
        }

        public OrderCreateViewModel(Order order, SelectList customers, SelectList products)
        {
            Order = order;
            Customers = customers;
            Products = products;
        }

        public Order Order { get; set; }
        public SelectList Customers { get; set; }
        public SelectList Products { get; set; }
    }
}