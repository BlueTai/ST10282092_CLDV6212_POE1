using System.Collections.Generic;
using TitanTech.Models;

namespace TitanTech.Models.ViewModels
{
    public class OrderIndexViewModel
    {
        public OrderIndexViewModel()
        {
            Orders = new List<Order>();
            Customers = new List<Customer>();
            Products = new List<Product>();
        }

        public OrderIndexViewModel(IEnumerable<Order> orders, IEnumerable<Customer> customers, IEnumerable<Product> products)
        {
            Orders = orders;
            Customers = customers;
            Products = products;
        }

        public IEnumerable<Order> Orders { get; set; }
        public IEnumerable<Customer> Customers { get; set; }
        public IEnumerable<Product> Products { get; set; }
    }
}