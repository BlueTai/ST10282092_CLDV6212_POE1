﻿namespace TitanTech.Models.ViewModels
{
    public class HomeViewModel
    {
        public HomeViewModel(IEnumerable<Product> featuredProducts)
        {
            FeaturedProducts = featuredProducts;
        }

        public HomeViewModel()
        {
         
        }

        public IEnumerable<Product> FeaturedProducts { get; set; }
        public int CustomerCount { get; set; }
        public int ProductCount { get; set; }
        public int OrderCount { get; set; }
    }
}