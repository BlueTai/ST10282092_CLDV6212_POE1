using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Azure;
using Azure.Data.Tables;

namespace TitanTech.Models;

// The model now inherits from ITableEntity.
public class Product : ITableEntity
{
    // Parameterless constructor required for Azure Table Storage deserialization
    public Product()
    {
        PartitionKey = string.Empty;
        RowKey = string.Empty;
        ProductName = string.Empty;
        Description = string.Empty;
        ImageUrl = string.Empty;
    }

    // ITableEntity properties are required.
    public Product(string partitionKey, string rowKey, DateTimeOffset? timestamp, ETag eTag, int productId, string productName, string description, decimal price, int stockAvailable, string imageUrl)
    {
        PartitionKey = partitionKey;
        RowKey = rowKey;
        Timestamp = timestamp;
        ETag = eTag;
        ProductId = productId;
        ProductName = productName;
        Description = description;
        Price = price;
        StockAvailable = stockAvailable;
        ImageUrl = imageUrl;
    }

    public string PartitionKey { get; set; } = string.Empty;
    public string RowKey { get; set; } = string.Empty;
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }

    public int ProductId { get; set; }

    [Required]
    [StringLength(100)]
    public string ProductName { get; set; } = string.Empty;

    [StringLength(500)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [Column(TypeName = "decimal(18, 2)")]
    public decimal Price { get; set; }

    [Required]
    public int StockAvailable { get; set; }

    [StringLength(255)]
    public string ImageUrl { get; set; } = string.Empty;
}