using System.ComponentModel.DataAnnotations;
using Azure;
using Azure.Data.Tables;

namespace TitanTech.Models;

// The model now inherits from ITableEntity to work with Azure Table Storage.
public class Customer : ITableEntity
{
    // Parameterless constructor required for Azure Table Storage deserialization
    public Customer()
    {
        PartitionKey = string.Empty;
        RowKey = string.Empty;
        Name = string.Empty;
        Surname = string.Empty;
        Username = string.Empty;
        Email = string.Empty;
        ShippingAddress = string.Empty;
    }

    // ITableEntity properties are required by Azure Table Storage.
    public Customer(string partitionKey, string rowKey, DateTimeOffset? timestamp, ETag eTag, int customerId, string name, string surname, string username, string email, string shippingAddress)
    {
        PartitionKey = partitionKey;
        RowKey = rowKey;
        Timestamp = timestamp;
        ETag = eTag;
        CustomerId = customerId;
        Name = name;
        Surname = surname;
        Username = username;
        Email = email;
        ShippingAddress = shippingAddress;
    }

    public string PartitionKey { get; set; } = string.Empty;
    public string RowKey { get; set; } = string.Empty;
    public DateTimeOffset? Timestamp { get; set; }
    public ETag ETag { get; set; }

    public int CustomerId { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Surname { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required]
    [StringLength(200)]
    public string ShippingAddress { get; set; } = string.Empty;
}