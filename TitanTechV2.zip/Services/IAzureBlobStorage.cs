﻿namespace TitanTech.Services;

public interface IAzureBlobService
{
    Task<string> UploadFileAsync(IFormFile file, string containerName);
    Task DeleteFileAsync(string fileName, string containerName);
}