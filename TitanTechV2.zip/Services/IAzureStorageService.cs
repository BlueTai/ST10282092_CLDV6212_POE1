﻿using TitanTech.Models;

namespace TitanTech.Services
{
    public interface IAzureStorageService
    {
        // Customer methods
        Task<IEnumerable<Customer>> GetAllCustomersAsync();
        Task<Customer> GetCustomerAsync(string rowKey);
        Task AddCustomerAsync(Customer customer);
        Task UpdateCustomerAsync(Customer customer);
        Task DeleteCustomerAsync(string rowKey);

        // Product methods
        Task<IEnumerable<Product>> GetAllProductsAsync();
        Task<Product> GetProductAsync(string rowKey);
        Task AddProductAsync(Product product);
        Task UpdateProductAsync(Product product);
        Task DeleteProductAsync(string rowKey);

        // Order methods
        Task<IEnumerable<Order>> GetAllOrdersAsync();
        Task<Order> GetOrderAsync(string rowKey);
        Task AddOrderAsync(Order order);
        Task UpdateOrderAsync(Order order);
        Task DeleteOrderAsync(string rowKey);
    }
}