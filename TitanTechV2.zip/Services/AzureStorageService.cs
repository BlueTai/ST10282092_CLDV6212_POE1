﻿using Azure.Data.Tables;
using TitanTech.Models;

namespace TitanTech.Services
{
    public class AzureStorageService : IAzureStorageService
    {
        private readonly TableClient _customerTable;
        private readonly TableClient _productTable;
        private readonly TableClient _orderTable;

        public AzureStorageService(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("AzureStorage");
            var serviceClient = new TableServiceClient(connectionString);

            // Initialize TableClients for each entity type.
            _customerTable = serviceClient.GetTableClient("Customers");
            _productTable = serviceClient.GetTableClient("Products");
            _orderTable = serviceClient.GetTableClient("Orders");

            // Create the tables if they don't exist.
            _customerTable.CreateIfNotExists();
            _productTable.CreateIfNotExists();
            _orderTable.CreateIfNotExists();
        }

        // --- Customer Methods ---
        public async Task<IEnumerable<Customer>> GetAllCustomersAsync()
        {
            var customers = new List<Customer>();
            var query = _customerTable.QueryAsync<Customer>();
            await foreach (var customer in query)
            {
                customers.Add(customer);
            }
            return customers;
        }

        public async Task<Customer> GetCustomerAsync(string rowKey)
        {
            var customer = await _customerTable.GetEntityAsync<Customer>("customer", rowKey);
            return customer.Value;
        }

        public async Task AddCustomerAsync(Customer customer)
        {
            customer.PartitionKey = "customer";
            customer.RowKey = customer.CustomerId.ToString();
            await _customerTable.AddEntityAsync(customer);
        }

        public async Task UpdateCustomerAsync(Customer customer)
        {
            customer.PartitionKey = "customer";
            customer.RowKey = customer.CustomerId.ToString();
            await _customerTable.UpdateEntityAsync(customer, customer.ETag);
        }

        public async Task DeleteCustomerAsync(string rowKey)
        {
            await _customerTable.DeleteEntityAsync("customer", rowKey);
        }

        // --- Product Methods ---
        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            var products = new List<Product>();
            var query = _productTable.QueryAsync<Product>();
            await foreach (var product in query)
            {
                products.Add(product);
            }
            return products;
        }

        public async Task<Product> GetProductAsync(string rowKey)
        {
            var product = await _productTable.GetEntityAsync<Product>("product", rowKey);
            return product.Value;
        }

        public async Task AddProductAsync(Product product)
        {
            product.PartitionKey = "product";
            product.RowKey = product.ProductId.ToString();
            await _productTable.AddEntityAsync(product);
        }

        public async Task UpdateProductAsync(Product product)
        {
            product.PartitionKey = "product";
            product.RowKey = product.ProductId.ToString();
            await _productTable.UpdateEntityAsync(product, product.ETag);
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            await _productTable.DeleteEntityAsync("product", rowKey);
        }

        // --- Order Methods ---
        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            var orders = new List<Order>();
            var query = _orderTable.QueryAsync<Order>();
            await foreach (var order in query)
            {
                orders.Add(order);
            }
            return orders;
        }

        public async Task<Order> GetOrderAsync(string rowKey)
        {
            var order = await _orderTable.GetEntityAsync<Order>("order", rowKey);
            return order.Value;
        }

        public async Task AddOrderAsync(Order order)
        {
            order.PartitionKey = "order";
            order.RowKey = order.OrderId.ToString();
            await _orderTable.AddEntityAsync(order);
        }

        public async Task UpdateOrderAsync(Order order)
        {
            order.PartitionKey = "order";
            order.RowKey = order.OrderId.ToString();
            await _orderTable.UpdateEntityAsync(order, order.ETag);
        }

        public async Task DeleteOrderAsync(string rowKey)
        {
            await _orderTable.DeleteEntityAsync("order", rowKey);
        }
    }
}